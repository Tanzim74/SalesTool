 <table class="salesTable display table table-striped table-bordered" id="language_option_table" style="width:100%">
     <thead>
    <tr>
        <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
             <th><?php echo e($header); ?></th>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
     </thead>
    
 </table>
<?php /**PATH C:\laragon\www\SalesTool\Original\SalesTool\laravel-tools\resources\views/datatables/sales-datatable.blade.php ENDPATH**/ ?>