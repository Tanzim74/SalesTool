<!DOCTYPE html>
<html lang="en" dir="">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title><?php echo $__env->yieldContent('title'); ?> | Gull Admin Template</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet" />
    <link href="<?php echo e(asset('dist-assets/css/themes/lite-purple.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('dist-assets/css/plugins/perfect-scrollbar.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="text-left">
    <div class="app-admin-wrap layout-sidebar-large">
        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
              <?php echo $__env->yieldContent('content'); ?>
             <!-- end of main-content -->
            </div><!-- Footer Start -->

           
            <!-- fotter end -->
        </div>
    </div><!-- ============ Search UI Start ============= -->
    <?php echo $__env->make('partials.search-ui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ============ Search UI End ============= -->
    <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\laragon\www\SalesTool\Original\SalesTool\laravel-tools\resources\views/welcome.blade.php ENDPATH**/ ?>