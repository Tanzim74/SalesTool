<?php
namespace App\Actions\SalesDatabaseService;

class SalesDatabaseService

{
    
//will use later   


}




?>