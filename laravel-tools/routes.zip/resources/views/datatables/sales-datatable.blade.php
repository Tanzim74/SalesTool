 <table class="salesTable display table table-striped table-bordered" id="language_option_table" style="width:100%">
     <thead>
    <tr>
        @foreach($headers as $header)
        
             <th>{{ $header }}</th>
        
        @endforeach
    </tr>
     </thead>
    
 </table>
