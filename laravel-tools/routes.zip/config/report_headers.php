<?php
return [
    'sales' => [

        'weekly' => [

            'columns' => [

                0 => 'WEEK NUMBER',
                1 => 'FROM',
                2 => 'TO',
                3 => 'TOTAL AMOUNT',
                
                
            ],
        ],
        'all' => [
            
            'columns' => [
                0 => 'ID',
                1 => 'DATE',
                2 => 'TOTAL SALES',
            ],
        ],
        'monthly' => [

            'columns' => [

                0 => 'MONTH NAME',
                1 => 'FROM',
                2 => 'TO',
                3 => 'TOTAL AMOUNT',
            ],

        ]


    ]
];

