<?php
return [
    'sales' => [

        'weekly' =>[

            'columnkeys' => [
                
                0 => 'week_number',
                1 => 'from_date',
                2 => 'to_date',
                3 => 'total_sales',
               
            ],
        ],
        'monthly' => [
            
            'columnkeys' => [
                
                0 => 'month_name',
                1 => 'from_date',
                2 => 'to_date',
                3 => 'total_sales',
            ],
            
        ],
        'all' => [
            'columnkeys' => [
                0 => 'id',
                1 => 'created_at',
                2 => 'amount'
            ],
        ],
     
     
        ]
    ];

    